const express = require('express');
const axios = require('axios');
const path = require('path');
const session = require('express-session');
const { URL } = require('url'); 

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(session({
    secret: 'wfcDOWNSecretKeySessionV2_Fixed', // Ganti dengan secret yang lebih kuat di produksi
    resave: false,
    saveUninitialized: true,
    cookie: { 
        secure: process.env.NODE_ENV === 'production', // true jika menggunakan HTTPS
        maxAge: 60 * 60 * 1000 // 1 jam, sesuaikan jika perlu
    }
}));

// Fungsi Helper TikTok (TikWM API)
async function tikwmFetch(url) {
    console.log(`Fetching TikTok data for URL: ${url}`);
    try {
        const response = await axios.get(`https://tikwm.com/api/?url=${encodeURIComponent(url)}`, {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36' },
            timeout: 20000 // 20 detik timeout
        });
        
        if (response.data && response.data.code === 0 && response.data.data) {
            const resultData = response.data.data;
            const enrichUrl = (path) => (path && path.startsWith('/')) ? 'https://tikwm.com' + path : path;
            
            resultData.play = enrichUrl(resultData.play);
            resultData.hdplay = enrichUrl(resultData.hdplay);
            resultData.music = enrichUrl(resultData.music);

            if (resultData.cover && resultData.cover.startsWith('//')) {
                resultData.cover = 'https:' + resultData.cover;
            } else {
                resultData.cover = enrichUrl(resultData.cover);
            }

            if (resultData.images && Array.isArray(resultData.images)) {
                resultData.images = resultData.images.map(imgUrl => {
                    if (imgUrl && imgUrl.startsWith('//')) return 'https:' + imgUrl;
                    return enrichUrl(imgUrl);
                });
            }
            if (resultData.author && resultData.author.avatar) {
                 if (resultData.author.avatar.startsWith('//')) {
                    resultData.author.avatar = 'https:' + resultData.author.avatar;
                 } else {
                    resultData.author.avatar = enrichUrl(resultData.author.avatar);
                 }
            }
            if(resultData.music_info && resultData.music_info.cover) {
                if (resultData.music_info.cover.startsWith('//')) {
                    resultData.music_info.cover = 'https:' + resultData.music_info.cover;
                } else {
                    resultData.music_info.cover = enrichUrl(resultData.music_info.cover);
                }
            }
            return resultData;
        } else if (response.data && response.data.msg) {
            throw new Error(`API TikWM Error: ${response.data.msg}`);
        } else {
            throw new Error("Gagal memproses permintaan dari API TikWM. Respons tidak terduga.");
        }
    } catch (error) {
        console.error(`tikwmFetch error: ${error.message}`);
        let errMsg = 'Gagal mengambil data TikTok. ';
        if (error.response?.data?.msg) errMsg += error.response.data.msg;
        else if (error.message.includes('timeout')) errMsg += 'Waktu permintaan habis.';
        else errMsg += 'Server API mungkin bermasalah atau URL tidak valid.';
        throw new Error(errMsg);
    }
}

// Fungsi Helper Spotify (Caliphdev API)
const SPOTIFY_API_BASE = 'https://spotifyapi.caliphdev.com';

function isValidSpotifyTrackUrl(url) {
    if (!url) return false;
    try {
        const parsedUrl = new URL(url);
        return parsedUrl.hostname === 'open.spotify.com' && parsedUrl.pathname.includes('/track/');
    } catch (e) {
        return false;
    }
}

async function spotifyFetchTrackInfo(trackUrl) {
    console.log(`Fetching Spotify track info for URL: ${trackUrl}`);
    try {
        const response = await axios.get(`${SPOTIFY_API_BASE}/api/info/track`, { 
            params: { url: trackUrl },
            timeout: 10000 
        });
        if (response.data && response.data.title) {
            return response.data;
        } else {
            throw new Error(response.data.message || "Gagal mendapatkan info trek Spotify dari API.");
        }
    } catch (error) {
        let errMsg = "Gagal mengambil info trek dari Spotify: ";
        if (error.code === 'ECONNABORTED') errMsg += "Request timeout ke API Spotify.";
        else errMsg += error.response?.data?.message || error.message;
        console.error(`spotifyFetchTrackInfo error: ${errMsg}`);
        throw new Error(errMsg);
    }
}

async function spotifySearchTracks(query) {
    console.log(`Searching Spotify tracks for query: ${query}`);
    try {
        const response = await axios.get(`${SPOTIFY_API_BASE}/api/search/tracks`, { 
            params: { q: query },
            timeout: 10000 
        });
        if (response.data && Array.isArray(response.data)) {
            return response.data; // Bisa array kosong jika tidak ada hasil
        } else {
             throw new Error(response.data.message || "Gagal mencari trek Spotify atau format respons tidak dikenal.");
        }
    } catch (error) {
        let errMsg = "Gagal mencari trek di Spotify: ";
        if (error.code === 'ECONNABORTED') errMsg += "Request timeout ke API Spotify.";
        else errMsg += error.response?.data?.message || error.message;
        console.error(`spotifySearchTracks error: ${errMsg}`);
        throw new Error(errMsg);
    }
}

// Endpoint untuk streaming audio Spotify (Proxy)
app.get('/stream/spotify', async (req, res) => {
    const trackUrl = req.query.url;
    if (!trackUrl || !isValidSpotifyTrackUrl(trackUrl)) {
        return res.status(400).send('URL trek Spotify tidak valid.');
    }
    try {
        console.log(`Attempting to stream Spotify track: ${trackUrl}`);
        const response = await axios.get(`${SPOTIFY_API_BASE}/api/download/track`, {
            params: { url: trackUrl },
            responseType: 'stream',
            timeout: 30000 // Timeout lebih panjang untuk download stream
        });
        res.setHeader('Content-Type', 'audio/mpeg');
        // Tambahkan header untuk filename saat download
        if (req.query.title && req.query.artist) {
            const filename = `${req.query.title.replace(/[^a-zA-Z0-9_]+/g, '_')} - ${req.query.artist.replace(/[^a-zA-Z0-9_]+/g, '_')}.mp3`;
            res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        }
        response.data.pipe(res);
        
        response.data.on('error', (streamError) => {
            console.error('Error during Spotify stream pipe:', streamError.message);
            if (!res.headersSent) {
                res.status(500).send('Gagal streaming audio (stream error).');
            }
        });

    } catch (error) {
        console.error('Error streaming Spotify audio:', error.message);
        if (error.code === 'ECONNABORTED') {
            res.status(504).send('Gagal streaming audio (timeout dari API sumber).');
        } else if (error.response && error.response.status === 404) {
            res.status(404).send('Sumber audio tidak ditemukan di API Spotify.');
        }
        else {
            res.status(500).send('Gagal streaming audio.');
        }
    }
});

// Rute Halaman Utama
app.get('/', (req, res) => {
    res.render('index', { 
        pageTitle: 'TikTok Video/Foto',
        navTitle: 'TikTok',
        tagline: 'Unduh Video & Foto TikTok Tanpa Watermark!'
    });
});

app.get('/tiktok-slide', (req, res) => {
    res.render('tiktok-slide', { 
        pageTitle: 'TikTok Slide',
        navTitle: 'TikTok Slide',
        tagline: 'Unduh Semua Gambar dari TikTok Slide!'
    });
});

app.get('/spotify', (req, res) => {
    const trackInfo = req.session.spotifyTrackInfo;
    const searchResults = req.session.spotifySearchResults;
    const error = req.session.spotifyError;
    const lastQuery = req.session.lastSpotifyQuery;

    delete req.session.spotifyTrackInfo;
    delete req.session.spotifySearchResults;
    delete req.session.spotifyError;
    delete req.session.lastSpotifyQuery;

    res.render('spotify', { 
        pageTitle: 'Spotify Downloader',
        navTitle: 'Spotify',
        tagline: 'Cari & Unduh Lagu Favoritmu dari Spotify!',
        spotifyTrackInfo: trackInfo,
        spotifySearchResults: searchResults,
        spotifyError: error,
        lastQuery: lastQuery || ''
    });
});

// Rute Download
app.post('/download/tiktok', async (req, res) => {
    const { url } = req.body;
    const tiktokRegex = /https?:\/\/(?:www\.|vm\.|vt\.)?tiktok\.com\//i;

    if (!url || !tiktokRegex.test(url)) {
        req.session.downloadError = 'URL TikTok tidak valid atau kosong.';
        req.session.downloaderType = 'tiktok'; // Untuk membedakan di halaman result
        return res.redirect('/result');
    }
    try {
        const data = await tikwmFetch(url);
        req.session.downloadResult = data;
        req.session.downloaderType = 'tiktok';
        req.session.downloadError = null; 
    } catch (error) {
        req.session.downloadResult = null;
        req.session.downloaderType = 'tiktok';
        req.session.downloadError = error.message || 'Kesalahan saat memproses TikTok.';
    }
    res.redirect('/result');
});

app.post('/download/spotify', async (req, res) => {
    const query = req.body.query ? req.body.query.trim() : ''; 
    req.session.lastSpotifyQuery = query; // Simpan query untuk prefill form

    if (!query) {
        req.session.spotifyError = 'Masukkan Link atau Judul Lagu Spotify.';
        return res.redirect('/spotify');
    }

    if (isValidSpotifyTrackUrl(query)) {
        try {
            const trackInfoFromApi = await spotifyFetchTrackInfo(query);
            // Sesuaikan nama field jika API Caliphdev berbeda dari ekspektasi ejs
            const formattedTrackInfo = {
                title: trackInfoFromApi.title,
                artist: Array.isArray(trackInfoFromApi.artists) ? trackInfoFromApi.artists.join(', ') : (trackInfoFromApi.artist || trackInfoFromApi.artists || 'N/A'),
                album: trackInfoFromApi.album || 'N/A',
                thumbnail: trackInfoFromApi.thumbnail || trackInfoFromApi.cover,
                url: query, // original spotify url
                duration: trackInfoFromApi.duration || 'N/A', // ejs mengharapkan string durasi
                // streamUrl akan digunakan untuk play dan download langsung
                streamUrl: `/stream/spotify?url=${encodeURIComponent(query)}&title=${encodeURIComponent(trackInfoFromApi.title || 'track')}&artist=${encodeURIComponent(Array.isArray(trackInfoFromApi.artists) ? trackInfoFromApi.artists.join(', ') : (trackInfoFromApi.artist || 'N/A'))}`
            };
            req.session.spotifyTrackInfo = formattedTrackInfo;
            req.session.spotifySearchResults = null;
            req.session.spotifyError = null;
        } catch (error) {
            req.session.spotifyTrackInfo = null;
            req.session.spotifyError = error.message || 'Gagal mendapatkan info lagu Spotify.';
        }
    } else {
        try {
            const searchResultsFromApi = await spotifySearchTracks(query);
            if (searchResultsFromApi.length === 0) {
                req.session.spotifyError = `Tidak ada hasil untuk "${query}". Coba kata kunci lain.`;
                req.session.spotifySearchResults = [];
            } else {
                // Map hasil pencarian ke format yang diharapkan EJS jika perlu
                req.session.spotifySearchResults = searchResultsFromApi.map(track => ({
                    title: track.title,
                    artist: Array.isArray(track.artists) ? track.artists.join(', ') : (track.artist || track.artists || 'N/A'),
                    thumbnail: track.thumbnail || track.cover,
                    url: track.url // Ini adalah URL Spotify lagu, bukan URL download
                })).slice(0,10); // Batasi hasil
                req.session.spotifyError = null;
            }
            req.session.spotifyTrackInfo = null;
        } catch (error) {
            req.session.spotifySearchResults = null;
            req.session.spotifyError = error.message || 'Gagal mencari lagu di Spotify.';
        }
    }
    return res.redirect('/spotify');
});

app.get('/result', (req, res) => {
    const results = req.session.downloadResult;
    const error = req.session.downloadError;
    const type = req.session.downloaderType;

    delete req.session.downloadResult;
    delete req.session.downloadError;
    delete req.session.downloaderType;

    res.render('result', {
        pageTitle: error ? 'Terjadi Kesalahan' : 'Hasil Unduhan',
        navTitle: 'Hasil', 
        results: results,
        error: error,
        type: type || 'tiktok' // default ke tiktok jika type tidak ada
    });
});

// Penanganan 404
app.use((req, res, next) => {
    res.status(404).render('result', {
        pageTitle: 'Halaman Tidak Ditemukan',
        navTitle: 'Error',
        results: null,
        error: 'Oops! Halaman yang Anda cari tidak dapat ditemukan (404).',
        type: 'error'
    });
});

// Penanganan Error Global
app.use((err, req, res, next) => {
    console.error("Global error handler:", err.stack);
    res.status(500).render('result', {
        pageTitle: 'Kesalahan Server',
        navTitle: 'Error',
        results: null,
        error: 'Maaf, terjadi kesalahan internal pada server (500). Coba lagi nanti.',
        type: 'error'
    });
});

app.listen(PORT, () => {
    console.log(`WFC DOWN server (EJS + Spotify + TikTok) berjalan di http://localhost:${PORT}`);
});