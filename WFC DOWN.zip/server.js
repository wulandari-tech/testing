const express = require('express');
const axios = require('axios');
const path = require('path');
const session = require('express-session');
const { URL } = require('url');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(session({
    secret: 'wfcDOWNSecretKeySessionV2',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, maxAge: 60000 * 10 } // 10 menit
}));
async function tikwmFetch(url) {
    console.log(`Fetching TikTok data for URL: ${url}`);
    try {
        const response = await axios.get(`https://tikwm.com/api/?url=${encodeURIComponent(url)}`, {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36' },
            timeout: 20000
        });
        
        if (response.data && response.data.code === 0 && response.data.data) {
            const resultData = response.data.data;
            const enrichUrl = (path) => (path && path.startsWith('/')) ? 'https://tikwm.com' + path : path;
            resultData.play = enrichUrl(resultData.play);
            resultData.hdplay = enrichUrl(resultData.hdplay);
            resultData.music = enrichUrl(resultData.music);
            if (resultData.cover && resultData.cover.startsWith('//')) resultData.cover = 'https:' + resultData.cover; else resultData.cover = enrichUrl(resultData.cover);
            if (resultData.images && Array.isArray(resultData.images)) resultData.images = resultData.images.map(enrichUrl);
            if (resultData.author && resultData.author.avatar) resultData.author.avatar = enrichUrl(resultData.author.avatar);
            if(resultData.music_info && resultData.music_info.cover && resultData.music_info.cover.startsWith('//')) resultData.music_info.cover = 'https:' + resultData.music_info.cover; else if (resultData.music_info && resultData.music_info.cover) resultData.music_info.cover = enrichUrl(resultData.music_info.cover);
            return resultData;
        } else if (response.data && response.data.msg) {
            throw new Error(`API TikWM Error: ${response.data.msg}`);
        } else {
            throw new Error("Gagal memproses permintaan dari API TikWM. Respons tidak terduga.");
        }
    } catch (error) {
        console.error(`tikwmFetch error: ${error.message}`);
        let errMsg = 'Gagal mengambil data TikTok. ';
        if (error.response?.data?.msg) errMsg += error.response.data.msg;
        else if (error.message.includes('timeout')) errMsg += 'Waktu permintaan habis.';
        else errMsg += 'Server API mungkin bermasalah atau URL tidak valid.';
        throw new Error(errMsg);
    }
}
const SPOTIFY_API_BASE = 'https://spotifyapi.caliphdev.com';

function isValidSpotifyTrackUrl(url) {
    try {
        const parsedUrl = new URL(url);
        return parsedUrl.hostname === 'open.spotify.com' && parsedUrl.pathname.includes('/track/');
    } catch (e) {
        return false;
    }
}

async function spotifyFetchTrackInfo(trackUrl) {
    console.log(`Fetching Spotify track info for URL: ${trackUrl}`);
    try {
        const response = await axios.get(`${SPOTIFY_API_BASE}/api/info/track`, { params: { url: trackUrl } });
        if (response.data && response.data.title) { // Asumsi sukses jika ada title
            return response.data;
        } else {
            throw new Error(response.data.message || "Gagal mendapatkan info trek Spotify.");
        }
    } catch (error) {
        console.error(`spotifyFetchTrackInfo error: ${error.response?.data?.message || error.message}`);
        throw new Error(`Gagal mengambil info trek dari Spotify: ${error.response?.data?.message || error.message}`);
    }
}

async function spotifySearchTracks(query) {
    console.log(`Searching Spotify tracks for query: ${query}`);
    try {
        const response = await axios.get(`${SPOTIFY_API_BASE}/api/search/tracks`, { params: { q: query } });
        if (response.data && Array.isArray(response.data) && response.data.length > 0) {
            return response.data; // Array of tracks
        } else if (response.data && Array.isArray(response.data) && response.data.length === 0) {
            return []; // No results
        } else {
             throw new Error(response.data.message || "Gagal mencari trek Spotify atau format respons tidak dikenal.");
        }
    } catch (error) {
        console.error(`spotifySearchTracks error: ${error.response?.data?.message || error.message}`);
        throw new Error(`Gagal mencari trek di Spotify: ${error.response?.data?.message || error.message}`);
    }
}

// Endpoint untuk streaming audio Spotify (Proxy)
app.get('/stream/spotify', async (req, res) => {
    const trackUrl = req.query.url;
    if (!trackUrl || !isValidSpotifyTrackUrl(trackUrl)) {
        return res.status(400).send('URL trek Spotify tidak valid.');
    }
    try {
        console.log(`Streaming Spotify track: ${trackUrl}`);
        const response = await axios.get(`${SPOTIFY_API_BASE}/api/download/track`, {
            params: { url: trackUrl },
            responseType: 'stream'
        });
        res.setHeader('Content-Type', 'audio/mpeg');
        response.data.pipe(res);
    } catch (error) {
        console.error('Error streaming Spotify audio:', error.message);
        res.status(500).send('Gagal streaming audio.');
    }
});

app.get('/', (req, res) => {
    res.render('index', { 
        pageTitle: 'TikTok Video/Foto',
        navTitle: 'TikTok',
        tagline: 'Unduh Video & Foto TikTok Tanpa Watermark!'
    });
});

app.get('/tiktok-slide', (req, res) => {
    res.render('tiktok-slide', { 
        pageTitle: 'TikTok Slide',
        navTitle: 'TikTok Slide',
        tagline: 'Unduh Semua Gambar dari TikTok Slide!'
    });
});

app.get('/spotify', (req, res) => {
    res.render('spotify', { 
        pageTitle: 'Spotify Downloader',
        navTitle: 'Spotify',
        tagline: 'Cari & Unduh Lagu Favoritmu dari Spotify!',
        searchResults: null,
        error: null
    });
});

app.post('/download/tiktok', async (req, res) => {
    const { url } = req.body;
    const tiktokRegex = /https?:\/\/(?:www\.|vm\.|vt\.)?tiktok\.com\//i;

    if (!url || !tiktokRegex.test(url)) {
        req.session.downloadError = 'URL TikTok tidak valid atau kosong.';
        req.session.downloaderType = 'tiktok';
        return res.redirect('/result');
    }
    try {
        const data = await tikwmFetch(url);
        req.session.downloadResult = data;
        req.session.downloaderType = 'tiktok';
        req.session.downloadError = null; 
    } catch (error) {
        req.session.downloadResult = null;
        req.session.downloaderType = 'tiktok';
        req.session.downloadError = error.message || 'Kesalahan saat memproses TikTok.';
    }
    res.redirect('/result');
});

app.post('/download/spotify', async (req, res) => {
    const { query } = req.body; 

    if (!query) {
        req.session.spotifyError = 'Masukkan Link atau Judul Lagu Spotify.';
        req.session.spotifySearchResults = null;
        req.session.spotifyTrackInfo = null;
        return res.redirect(req.get('referer') || '/spotify'); // Kembali ke halaman Spotify
    }

    if (isValidSpotifyTrackUrl(query)) {
        // Ini adalah URL, langsung coba ambil info dan link download
        try {
            const trackInfo = await spotifyFetchTrackInfo(query);
            req.session.spotifyTrackInfo = { ...trackInfo, streamUrl: `/stream/spotify?url=${encodeURIComponent(query)}` };
            req.session.spotifySearchResults = null;
            req.session.spotifyError = null;
        } catch (error) {
            req.session.spotifyTrackInfo = null;
            req.session.spotifyError = error.message || 'Gagal mendapatkan info lagu Spotify.';
        }
    } else {
        try {
            const searchResults = await spotifySearchTracks(query);
            if (searchResults.length === 0) {
                req.session.spotifyError = `Tidak ada hasil untuk "${query}". Coba kata kunci lain.`;
                req.session.spotifySearchResults = [];
            } else {
                req.session.spotifySearchResults = searchResults;
                req.session.spotifyError = null;
            }
            req.session.spotifyTrackInfo = null;
        } catch (error) {
            req.session.spotifySearchResults = null;
            req.session.spotifyError = error.message || 'Gagal mencari lagu di Spotify.';
        }
    }
    // Redirect kembali ke halaman spotify untuk menampilkan hasil atau form lagi
    // Kita tidak redirect ke /result karena Spotify punya flow Search & Download
    return res.redirect(req.get('referer') || '/spotify');
});


app.get('/result', (req, res) => {
    const results = req.session.downloadResult;
    const error = req.session.downloadError;
    const type = req.session.downloaderType;

    // Hapus data sesi setelah digunakan
    delete req.session.downloadResult;
    delete req.session.downloadError;
    delete req.session.downloaderType;

    res.render('result', {
        pageTitle: 'Hasil Unduhan',
        navTitle: 'Hasil', 
        results: results,
        error: error,
        type: type
    });
});

app.listen(PORT, () => {
    console.log(`WFC DOWN server (EJS + Spotify) berjalan di http://localhost:${PORT}`);
});